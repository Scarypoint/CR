Tutorial Menjalankan Aplikasi Java


1. Open Project Ke Netbeans Anda
2. Jalan kan Xampp anda, klik tombol start di mysql dan apache. lalu buka localhost/phpmyadmin di web browser masing masing
3. Klik Import dan pilih database db_crudjava.sql di .zip yang sudah terdownload
4. Jalankan aplikasi yang sudah terbuka di netbeans
5. Aplikasi Siap Dipakai :)

Semoga Aplikasi Ini Bisa Bermanfaat Bagi Yang Membutuhkan
