<?php
include("db.php");

if(isset($_GET['Guia'])) {
  $Guia = $_GET['Guia'];
  $query = "DELETE FROM cch WHERE cch = ?";
  $stmt = $conn->prepare($query);
  $stmt->bind_param("s", $conn);
  
  if($stmt->execute()) {
    $_SESSION['message'] = 'Task Removed Successfully';
    $_SESSION['message_type'] = 'danger';
  } else {
    $_SESSION['message'] = 'Failed to Remove Task';
    $_SESSION['message_type'] = 'danger';
  }

  $stmt->close();
  $conn->close();
  
  header('Location: index.php');
  exit();
}
?>
