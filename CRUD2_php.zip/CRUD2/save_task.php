<?php

include('db.php');

if (isset($_POST['Guardar'])) {
  $Codigo = $_POST['Codigo'];
  $Nombre = $_POST['Nombre'];
    $Precio = $_POST['Precio'];
     $Cantidad = $_POST['Cantidad'];
  $query = "INSERT INTO Paquetes(Codigo,Nombre,Precio,Cantidad)VALUES ('$Codigo','Nombre','$Precio','$Cantidad')";
  $result = mysqli_query($conn, $query);
  if(!$result) {
    die("Query Failed.");
  }

  $_SESSION['message'] = 'Guardado';
  $_SESSION['message_type'] = 'success';
  header('Location: index.php');

}

?>
