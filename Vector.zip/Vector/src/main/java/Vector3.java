/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

/**
 *
 * @author miakh
 */
public class Vector3 {

    public static void main(String[] args) {
         int[] intArray={2,5,46,12,34};
               
               for(int i=0;i<intArray.length;i++){ 
                   System.out.println(intArray[i]);
        
    }
               
             String[]apellidos = new String[3];
            apellidos[0]="Lopez";
            apellidos[1]="Hernandez";
            apellidos[2]="Gonzalez";
             for(int i=0;i<apellidos.length;i++){ 
                   System.out.println(apellidos[i]);
        
      }  
    }
}
   
