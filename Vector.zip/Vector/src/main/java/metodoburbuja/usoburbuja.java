/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package metodoburbuja;

import java.util.Arrays;

/**
 *
 * @author miakh
 */
public class usoburbuja {
public static void main(String[] args) {
        int numeros[] = {2, 3, 4, 5, 6, 7, 8, 9, 10};
        System.out.println("Antes del método de la burbuja: " + Arrays.toString(numeros));
        burbuja(numeros);
        System.out.println("Después del método de la burbuja: " + Arrays.toString(numeros));
        String[] nombres = {"Juan", "Maria", "Roberto", "Fernando", "Belen"};
        System.out.println("Antes del método de la burbuja: " + Arrays.toString(nombres));
        burbuja(nombres);
        System.out.println("Después del método de la burbuja: " + Arrays.toString(nombres));
    }

 private static void burbuja(int[] arreglo) {
        for (int x = 0; x < arreglo.length; x++) {
            // Aquí "y" se detiene antes de llegar
            // a length - 1 porque dentro del for, accedemos
            // al siguiente elemento con el índice actual + 1
            for (int y = 0; y < arreglo.length - 1; y++) {
                int elementoActual = arreglo[y],
                        elementoSiguiente = arreglo[y + 1];
                if (elementoActual > elementoSiguiente) {
                    // Intercambiar
                    arreglo[y] = elementoSiguiente;
                    arreglo[y + 1] = elementoActual;
                }
            }
        }
    }
 
 private static void burbuja(String[] arreglo) {
        for (int x = 0; x < arreglo.length; x++) {
            // Aquí "y" se detiene antes de llegar
            // a length - 1 porque dentro del for, accedemos
            // al siguiente elemento con el índice actual + 1
            for (int y = 0; y < arreglo.length - 1; y++) {
                String elementoActual = arreglo[y],
                        elementoSiguiente = arreglo[y + 1];
                if (elementoActual.compareTo(elementoSiguiente) > 0) {
                    // Intercambiar
                    arreglo[y] = elementoSiguiente;
                    arreglo[y + 1] = elementoActual;
                }
            }
        }
    }
}
